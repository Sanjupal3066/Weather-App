package OpenWeatherApp;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Date1 {
	static int intDate=0;
	Date1()
	{
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd");  
	    String strDate = formatter.format(date);  
	    intDate = Integer.parseInt(strDate);
	   
	}
	public static void main(String args[])
	{
		new Date1();
	}

}
