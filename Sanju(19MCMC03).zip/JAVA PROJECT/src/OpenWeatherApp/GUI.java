package OpenWeatherApp;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.json.JSONObject;

public class GUI extends JFrame implements ActionListener 
{
	private static final long serialVersionUID = 1L;				//Serialization is used for saving the state which can help us to resume from the same state
	JLabel background = null;				//used for main Background image
	JTextField search = null;				
	JButton searchclick = null;
	JLabel info = null;
	JLabel temp = null;
	JLabel humidity = null;
	JLabel d_pic[] = new JLabel[5];				//Used for displaying the picture of all 5 next days
	JLabel d[] = new JLabel[5];					//Used for displaying the day name of next 5 days
	Font f3 = null;
	JLabel d_min[] = new JLabel[5];				//Used for displaying the Minimum temperature of next 5 days
	JLabel d_max[] = new JLabel[5];				//Used for displaying the Maximum temperature of next 5 days
	JLabel city = null;
	JLabel loc = null;							//Used for displaying the location symbol
	JLabel wind = null;
	JLabel feels = null; 

	GUI(String s) 
	{
		new API4(s);						//Calling the Constructor for intializing the static values so we can use it later in our program(It's a Parameterized Constructor which contain location)
		new API1(s);						//Calling the Constructor for intializing the static values so we can use it later in our program(It's a Parameterized Constructor which contain location)
		Date2 day = new Date2();
		Date2 day2=null;

		ObjectOutputStream oos=null;
		ObjectInputStream ois =null;
		try									//Object Serialization
		{
			File fhand = new File("ObjSerialization.txt");
			FileOutputStream fos = new FileOutputStream(fhand);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(day);
		
			FileInputStream fis = new FileInputStream(fhand);
			ois = new ObjectInputStream(fis);
			day2 = (Date2)ois.readObject();
			day2.start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				oos.close();
				ois.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		searchclick = new JButton("");
		search = new JTextField(40);
		
		info = new JLabel(API1.weather_info);
		info.setFont(new Font(Font.DIALOG, Font.BOLD, 40));
		info.setForeground(Color.WHITE);
		temp = new JLabel(API1.curr_weather + "\u00B0");
		temp.setFont(new Font(Font.DIALOG, Font.PLAIN, 80));
		temp.setForeground(Color.WHITE);

		loc = new JLabel("");
		
		feels = new JLabel("Feels Like : " + API1.feels + "\u00B0");
		feels.setForeground(Color.WHITE);
		feels.setFont(new Font(Font.DIALOG, Font.PLAIN, 15));

		humidity = new JLabel("Humidity : " + API1.humidity + "%");
		humidity.setForeground(Color.WHITE);
		humidity.setFont(new Font(Font.DIALOG, Font.PLAIN, 15));
		
		wind = new JLabel("Wind Speed : " + API1.wind_speed + "m/s");
		wind.setForeground(Color.WHITE);
		wind.setFont(new Font(Font.DIALOG, Font.PLAIN, 15));
		
		city = new JLabel(API1.loc);
		city.setForeground(Color.WHITE);
		city.setFont(new Font(Font.DIALOG, Font.PLAIN, 20));
		
	
		
		Font f = new Font(Font.DIALOG, Font.PLAIN, 20);
		
		for (int i = 0; i < 5; i++) 
		{
			d_pic[i] = new JLabel("");
		}

		for (int i = 0; i < 5; i++) 
		{
			d[i] = new JLabel(day2.day_name[i]);
			d[i].setFont(f);
			d[i].setForeground(Color.WHITE);
		}
		Font f_min = new Font(Font.DIALOG, Font.PLAIN, 15);

		for (int i = 0; i < 5; i++) 
		{
			d_min[i] = new JLabel("Min : " + API4.list_of_data.get(i).min_temp + "\u00B0");
			d_max[i] = new JLabel("Max : " + API4.list_of_data.get(i).max_temp + "\u00B0");

			d_min[i].setFont(f_min);
			d_min[i].setForeground(Color.WHITE);

			d_max[i].setFont(f_min);
			d_max[i].setForeground(Color.WHITE);
		}

		setBackground();
		setCord();
		addIntoFrame();
		registerbutton();
		frameProp();
	}

	public void registerbutton()
	{
		searchclick.addActionListener(this);
	}

	public void frameProp() 
	{
		setSize(750, 600);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setTitle("Open Weather App");
	}

	public void addIntoFrame() 
	{
		add(background);
		background.add(search);
		background.add(searchclick);
		background.add(info);
		background.add(temp);
		background.add(loc);
		background.add(wind);
		background.add(feels);
		background.add(humidity);
		background.add(city);
		for (int i = 0; i < 5; i++) 
		{
			background.add(d[i]);
		}
		for (int i = 0; i < 5; i++) 
		{
			background.add(d_pic[i]);
		}
		for (int i = 0; i < 5; i++) 
		{
			background.add(d_min[i]);
			background.add(d_max[i]);
		}
	}

	public void setCord() 
	{
		background.setBounds(0, 0, 750, 600);
		search.setBounds(450, 40, 200, 40);
		searchclick.setBounds(650, 40, 40, 40);
		info.setBounds(20, 50, 300, 50);
		temp.setBounds(20, 100, 300, 100);
		feels.setBounds(20, 180, 160, 60);
		humidity.setBounds(20, 200, 160, 60);
		wind.setBounds(20, 220, 250, 60);
		city.setBounds(30, 510, 250, 40);
		loc.setBounds(0, 510, 40, 40);
		int x = 60;
		for (int i = 0; i < 5; i++) 
		{
			if (i < 2) 
			{
				d[i].setBounds(40 + x, 300, 120, 50);
				x = x + 120;
			} 
			else if (i < 4) 
			{
				d[i].setBounds(50 + x, 300, 150, 50);
				x = x + 140;
			} 
			else 
			{
				d[i].setBounds(40 + x, 300, 150, 50);
			}
		}
		
		int x_pic = 0;
		for (int i = 0; i < 5; i++) 
		{
			d_pic[i].setBounds(60 + x_pic, 350, 100, 90);
			x_pic = x_pic + 130;
		}
		
		int x_min = 0;
		for (int i = 0; i < 5; i++) 
		{
			d_min[i].setBounds(70 + x_min, 470, 100, 20);
			x_min = x_min + 130;
		}
		
		int x_max = 0;
		for (int i = 0; i < 5; i++) 
		{
			d_max[i].setBounds(70 + x_max, 450, 100, 20);
			x_max = x_max + 130;
		}	
	}

	public void setBackground() 
	{
		ImageIcon img = new ImageIcon("BGclearnew.jpg");
		background = new JLabel("", img, JLabel.LEFT);

		searchclick.setIcon(new ImageIcon("search2.png"));

		loc.setIcon(new ImageIcon("loc-plus.png"));
		
		for (int i = 0; i < 5; i++) 
		{
			try 				//Assigning the image from the API Directly
			{
				d_pic[i].setIcon(new ImageIcon(
						ImageIO.read(new URL("http://openweathermap.org/img/wn/" + API4.list_of_data.get(i).Icon + "@2x.png"))));
			}
			catch (MalformedURLException e)
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		String location = search.getText();				//Taking the input from the Search TextField
		int flag = 0;
		int cod = 0;
		FileWriter fw = null;
		if (location.length() > 0) 
		{
			try 
			{
				URL weather = new URL("https://api.openweathermap.org/data/2.5/weather?q=" + location
						+ ",IN&APPID=e39535554664f4327a3815291cabbc25&units=metric");
				URLConnection con = weather.openConnection();
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine = in.readLine();
				JSONObject j1 = new JSONObject(inputLine.toString());
				cod = j1.getInt("cod");
				if (cod == 200)												//It Compare the value with the retrieved value if it's 200 means OK or if it's not 200 (most probably 404) means error
				{	
					new GUI(location);
					dispose();								//It is used for destroying the older windows which is open
				} 
				else 
				{
					JOptionPane.showMessageDialog(this, "Enter Valid Location");		//It is used for showing the message in alert format
				}
			}
			catch (Exception ef) 
			{
				flag = 1;
			}
			try
			{    
		           fw=new FileWriter("Searches.txt",true);
		           if(cod == 200)
		           {
		        	   fw.write(location+"\n");
		           }
		           else
		           {
		        	   fw.write(location+"(Invalid Location)\n");
		           }   
		     }
			catch(Exception ep)
			{
				System.out.println(e);
			}    
			finally
			{
				try 
				{
					fw.close();
				} 
				catch (IOException e1)
				{
					e1.printStackTrace();
				}
			}
		}
		if (flag == 1) 
		{
			JOptionPane.showMessageDialog(this, "Enter Valid Location");
		}
	}

	public static void main(String args[]) 
	{

	}
}
