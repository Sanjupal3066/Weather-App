package OpenWeatherApp;

import java.io.Serializable;
import java.util.Calendar;

public class Date2 extends Thread implements Serializable {
	
	private static final long serialVersionUID = 1L;
	String day_name[] = new String[5];					//It's used for Storing the day_name of next 5 days
	public void run()
	{
		Calendar c = Calendar.getInstance(); 
		String[] days = new String[] { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
		
		int curr_day = c.get(Calendar.DAY_OF_WEEK)-1;
		int i = 0;
		while(i<5)
		{
			day_name[i] = days[(curr_day+i+1)%7];					//It will give value only in between 0 to 6 
			i++;
		}
	}
	public static void main(String args[])
	{
		
	}
}