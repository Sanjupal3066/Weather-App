package OpenWeatherApp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
class data4
{
	double min_temp;
	double max_temp;
	String Icon;
	data4(double min,double max,String s)
	{
		this.min_temp = min;
		this.max_temp = max;
		this.Icon = s;
	}
	public String toString()
	{
		return "Min:"+min_temp+"\tMax:"+max_temp+"\tIcon:"+Icon;
	}
}
public class API4 														//This class is used for forecast
{
	static List<data4> list_of_data = new ArrayList<>(5);				//Making ArrayList of data_class type
	API4(String s) 
	{
		try 
		{
			new Date1();
			URL forecast = new URL(
					"https://api.openweathermap.org/data/2.5/forecast?q="+s+",IN&APPID=e39535554664f4327a3815291cabbc25&units=metric");
			URLConnection con = forecast.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine = in.readLine();

			JSONObject j1 = new JSONObject(inputLine.toString());
			JSONArray j2 = j1.getJSONArray("list");
			JSONObject j3 = j2.getJSONObject(0);
			JSONObject j4 = j3.getJSONObject("main");
			double min = j4.getDouble("temp_min");
			double max = j4.getDouble("temp_max");
			String date = j3.getString("dt_txt");
			char day[] = new char[2]; 
			date.getChars(8, 10, day, 0);										//Taking the "hour" only from the whole string
			int num1 = Character.getNumericValue(day[0]);						//Converting the character into integer 
			int num2 = Character.getNumericValue(day[1]);
			int temp_date = num1 * 10 + num2;									//Doing some calculation for getting the value in Integer format
			int r = 0;
			
			int j = 0,i = 0;
			int curr_date = Date1.intDate;
			while(curr_date == temp_date)
			{
				j3 = j2.getJSONObject(j);
				date = j3.getString("dt_txt");
				date.getChars(8, 10, day, 0);										//Taking the "hour" only from the whole string
				num1 = Character.getNumericValue(day[0]);						//Converting the character into integer 
				num2 = Character.getNumericValue(day[1]);
				temp_date = num1 * 10 + num2;
				j++;
			}
			String main_icon="";
			char temp_icon[] = new char[2]; 
			for(i = j ; i < j2.length() ; i++)
			{
				j3 = j2.getJSONObject(i);
				date = j3.getString("dt_txt");
				date.getChars(8, 10, day, 0);
				num1 = Character.getNumericValue(day[0]);
				num2 = Character.getNumericValue(day[1]);
				int new_date = num1 * 10 + num2;
				j4 = j3.getJSONObject("main");
				JSONArray j5 = j3.getJSONArray("weather");
				JSONObject j6 = j5.getJSONObject(0);
				date.getChars(11, 13, temp_icon ,0);
				num1 = Character.getNumericValue(temp_icon[0]);
				num2 = Character.getNumericValue(temp_icon[1]);
				int new_time = num1 * 10 + num2;
				if(new_time == 12 || i == 39)												//We are assigning the Icon image on the base of time(It show the icon of 12:00 or when the last iteration reached(24-Hour Format))
				{
					main_icon = j6.getString("icon");
				}
				if(temp_date == new_date && i != 39)
				{
					double new_min = j4.getDouble("temp_min");
					double new_max = j4.getDouble("temp_max");
					if(new_min < min)										//Taking the minimum temperature
					{
						min = new_min;
					}
					if(new_max > max)										//Taking the maximum temperature
					{
						max = new_max;
					}
				}
				else
				{
					temp_date = new_date;
					if((main_icon.compareTo("") == 0))
					{	
					}
					else
					{
						list_of_data.add(r,new data4(min,max,main_icon));		//Adding the data to list on the basis of index value(r)
						r++;
					}
					min = j4.getDouble("temp_min");
					max = j4.getDouble("temp_max");
					
				}
			}
			
			in.close();
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws ParseException
	{
	}

}
