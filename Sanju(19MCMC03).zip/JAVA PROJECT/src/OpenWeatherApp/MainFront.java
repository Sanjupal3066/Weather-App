package OpenWeatherApp;

public class MainFront 
{
	public static void main(String args[]) 
	{
		new GUI("Chandigarh");
	}
}