package OpenWeatherApp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.json.JSONArray;
import org.json.JSONObject;

public class API1 								//This class is used for getting the current weather information
{
	static double curr_weather = 0.0;
	static double feels = 0.0;
	static int humidity = 0;					//Humidity is given in percentage
	static double wind_speed = 0.0;				//wind speed is given in Meter per second(m/s)
	static String weather_info;
	static String loc;
	API1(String s)
	{
		try 
		{
			URL weather = new URL(
					"https://api.openweathermap.org/data/2.5/weather?q="+s+",IN&APPID=e39535554664f4327a3815291cabbc25&units=metric");		//Making the URL
			URLConnection con = weather.openConnection();																					//Try to make the Connection
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));						//Reading all the data
			String inputLine = in.readLine();																	//Converting into String so we can easily change into JSONObject and parse form it

			JSONObject j1 = new JSONObject(inputLine.toString());												//Converting into JSONObject
			
			JSONArray j2 = j1.getJSONArray("weather");															//Taking the Array whose name is "weather"
			JSONObject j3 = j2.getJSONObject(0);																//Taking the 0 index values
			weather_info = j3.getString("main");																//From the 0 index we are taking the value of "main"
			
			loc = j1.getString("name");																			//It's not in any array or Object so we directly parse it using main JSONObject(j1)
				
			JSONObject j5 = j1.getJSONObject("main");
			curr_weather = j5.getDouble("temp");																//Now this field is giving the value in double format so we store it in Double Dtype
			feels = j5.getDouble("feels_like");
			humidity = j5.getInt("humidity");
			JSONObject j6 = j1.getJSONObject("wind");
			wind_speed = j6.getDouble("speed");
			
			in.close();
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args) 
	{
		
	}

}
